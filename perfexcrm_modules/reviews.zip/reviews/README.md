# Reviews Module (Perfex CRM 3.3) - v1.1.0

## Cambio principal
- Se agregó **rating 1–5** (campo `rating`) para cada reseña.

## Endpoint para tu app (nuevo campo)
**POST** `/reviews/api/submit` (multipart/form-data)
- `rating` (opcional) => número entero 1..5

## Admin
- Columna **Rating** con estrellas.
