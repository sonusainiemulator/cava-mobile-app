<?php defined('BASEPATH') or exit('No direct script access allowed');

class Reviews_model extends App_Model
{
    private function table()
    {
        return db_prefix() . 'reviews';
    }

    public function get($id)
    {
        $this->db->where('id', (int)$id);
        return $this->db->get($this->table())->row();
    }

    public function add($data)
    {
        $data['created_at'] = isset($data['created_at']) ? $data['created_at'] : date('Y-m-d H:i:s');
        $data['approved']   = isset($data['approved']) ? (int)$data['approved'] : 0;

        if (isset($data['rating']) && $data['rating'] !== null) {
            $data['rating'] = (int)$data['rating'];
            if ($data['rating'] < 1 || $data['rating'] > 5) {
                $data['rating'] = null;
            }
        }

        $this->db->insert($this->table(), $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        $this->db->where('id', (int)$id);
        return $this->db->update($this->table(), $data);
    }

    public function delete($id)
    {
        $row = $this->get($id);
        if ($row && !empty($row->media_path)) {
            $full = FCPATH . ltrim($row->media_path, '/');
            if (is_file($full)) {
                @unlink($full);
            }
        }
        $this->db->where('id', (int)$id);
        return $this->db->delete($this->table());
    }

    public function list_admin($approvedFilter = null)
    {
        if ($approvedFilter !== null) {
            $this->db->where('approved', (int)$approvedFilter);
        }
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get($this->table())->result_array();
    }

    public function list_public_approved($limit = 50, $offset = 0)
    {
        $this->db->where('approved', 1);
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit((int)$limit, (int)$offset);
        return $this->db->get($this->table())->result_array();
    }
}
