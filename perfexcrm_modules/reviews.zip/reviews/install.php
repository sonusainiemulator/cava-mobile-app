<?php defined('BASEPATH') or exit('No direct script access allowed');

$CI = &get_instance();

$table = db_prefix() . 'reviews';

if (!$CI->db->table_exists($table)) {
    $CI->db->query("CREATE TABLE `" . $table . "` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `user_id` VARCHAR(64) NULL DEFAULT NULL,
        `user_name` VARCHAR(191) NULL DEFAULT NULL,
        `user_email` VARCHAR(191) NULL DEFAULT NULL,
        `rating` TINYINT(1) NULL DEFAULT NULL,
        `review_text` TEXT NULL DEFAULT NULL,
        `media_path` VARCHAR(255) NULL DEFAULT NULL,
        `media_type` ENUM('image','video') NULL DEFAULT NULL,
        `created_at` DATETIME NOT NULL,
        `approved` TINYINT(1) NOT NULL DEFAULT 0,
        `approved_by` INT(11) NULL DEFAULT NULL,
        `approved_at` DATETIME NULL DEFAULT NULL,
        PRIMARY KEY (`id`),
        INDEX `approved` (`approved`),
        INDEX `created_at` (`created_at`),
        INDEX `rating` (`rating`)
    ) ENGINE=InnoDB DEFAULT CHARSET=" . $CI->db->char_set . ";");
} else {
    // Add rating column if upgrading from older versions
    $columns = $CI->db->query("SHOW COLUMNS FROM `" . $table . "` LIKE 'rating'")->result_array();
    if (count($columns) === 0) {
        $CI->db->query("ALTER TABLE `" . $table . "` ADD `rating` TINYINT(1) NULL DEFAULT NULL AFTER `user_email`;");
        $CI->db->query("ALTER TABLE `" . $table . "` ADD INDEX `rating` (`rating`);");
    }
}

if (!is_dir(REVIEWS_UPLOAD_PATH)) {
    @mkdir(REVIEWS_UPLOAD_PATH, 0755, true);
}
