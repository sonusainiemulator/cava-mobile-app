<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <div class="clearfix">
              <h4 class="pull-left"><?php echo _l('reviews_title'); ?></h4>
              <div class="pull-right">
                <div class="btn-group">
                  <a href="<?php echo admin_url('reviews?filter=pending'); ?>" class="btn btn-default <?php echo ($filter=='pending'?'active':''); ?>">
                    <?php echo _l('reviews_pending'); ?>
                  </a>
                  <a href="<?php echo admin_url('reviews?filter=approved'); ?>" class="btn btn-default <?php echo ($filter=='approved'?'active':''); ?>">
                    <?php echo _l('reviews_approved'); ?>
                  </a>
                  <a href="<?php echo admin_url('reviews?filter=all'); ?>" class="btn btn-default <?php echo ($filter=='all'?'active':''); ?>">
                    <?php echo _l('reviews_all'); ?>
                  </a>
                </div>
              </div>
            </div>

            <hr class="hr-panel-heading" />

            <?php if (empty($reviews)) { ?>
              <p class="text-muted"><?php echo _l('reviews_no_records'); ?></p>
            <?php } else { ?>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th><?php echo _l('reviews_user'); ?></th>
                      <th><?php echo _l('reviews_date'); ?></th>
                      <th><?php echo _l('reviews_rating'); ?></th>
                      <th><?php echo _l('reviews_text'); ?></th>
                      <th><?php echo _l('reviews_media'); ?></th>
                      <th><?php echo _l('reviews_status'); ?></th>
                      <th><?php echo _l('reviews_actions'); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($reviews as $r) { ?>
                      <tr>
                        <td><?php echo (int)$r['id']; ?></td>
                        <td>
                          <strong><?php echo html_escape($r['user_name']); ?></strong><br>
                          <small class="text-muted"><?php echo html_escape($r['user_id']); ?><?php echo !empty($r['user_email']) ? ' • '.html_escape($r['user_email']) : ''; ?></small>
                        </td>
                        <td><?php echo _dt($r['created_at']); ?></td>
                        <td>
                          <?php
                            $rating = isset($r['rating']) ? (int)$r['rating'] : 0;
                            if ($rating < 1 || $rating > 5) {
                              echo '<span class="text-muted">—</span>';
                            } else {
                              for ($i=1; $i<=5; $i++) {
                                echo $i <= $rating ? '<i class="fa fa-star text-warning"></i>' : '<i class="fa fa-star-o text-muted"></i>';
                              }
                              echo ' <small class="text-muted">(' . $rating . '/5)</small>';
                            }
                          ?>
                        </td>
                        <td style="max-width:360px;">
                          <?php echo nl2br(html_escape($r['review_text'] ?? '')); ?>
                        </td>
                        <td style="min-width:220px;">
                          <?php if (!empty($r['media_path'])) { ?>
                            <?php if ($r['media_type'] === 'image') { ?>
                              <a href="<?php echo base_url($r['media_path']); ?>" target="_blank">
                                <img src="<?php echo base_url($r['media_path']); ?>" style="max-height:80px;border-radius:6px;">
                              </a>
                            <?php } elseif ($r['media_type'] === 'video') { ?>
                              <video controls style="max-height:90px;max-width:200px;border-radius:6px;">
                                <source src="<?php echo base_url($r['media_path']); ?>">
                              </video>
                            <?php } else { ?>
                              <a href="<?php echo base_url($r['media_path']); ?>" target="_blank"><?php echo basename($r['media_path']); ?></a>
                            <?php } ?>
                          <?php } else { ?>
                            <span class="text-muted">—</span>
                          <?php } ?>
                        </td>
                        <td>
                          <?php if ((int)$r['approved'] === 1) { ?>
                            <span class="label label-success"><?php echo _l('reviews_approved'); ?></span>
                          <?php } else { ?>
                            <span class="label label-warning"><?php echo _l('reviews_pending'); ?></span>
                          <?php } ?>
                        </td>
                        <td>
                          <?php if (has_permission('reviews','', 'approve')) { ?>
                            <div class="checkbox checkbox-primary" style="margin:0;">
                              <input type="checkbox" class="js-review-approve" data-id="<?php echo (int)$r['id']; ?>" <?php echo ((int)$r['approved']===1?'checked':''); ?>>
                              <label><?php echo _l('reviews_approve'); ?></label>
                            </div>
                            <a href="<?php echo admin_url('reviews/delete/'.(int)$r['id']); ?>" class="btn btn-xs btn-danger" onclick="return confirm('¿Eliminar?');">
                              <i class="fa fa-trash"></i>
                            </a>
                          <?php } ?>
                        </td>
                      </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            <?php } ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
<script>
(function () {
  function post(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.onload = function () {
      try { cb(JSON.parse(xhr.responseText)); } catch(e){ cb({success:false}); }
    };
    xhr.send();
  }

  var els = document.querySelectorAll('.js-review-approve');
  for (var i=0;i<els.length;i++){
    (function(el){
      el.addEventListener('change', function(){
        var id = el.getAttribute('data-id');
        post('<?php echo admin_url('reviews/toggle_approve/'); ?>'+id, function(resp){
          if(!resp || !resp.success){
            alert(resp && resp.message ? resp.message : 'Error');
            el.checked = !el.checked;
            return;
          }
          window.location.reload();
        });
      });
    })(els[i]);
  }
})();
</script>
</body>
</html>
