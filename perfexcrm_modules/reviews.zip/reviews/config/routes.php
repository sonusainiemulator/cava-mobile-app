<?php defined('BASEPATH') OR exit('No direct script access allowed');

$route['reviews/api/submit'] = 'reviews/api/submit';
$route['reviews/api/list']   = 'reviews/api/list_public';
