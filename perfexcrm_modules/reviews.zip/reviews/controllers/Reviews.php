<?php defined('BASEPATH') or exit('No direct script access allowed');

class Reviews extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('reviews_model');
        $this->lang->load('reviews', 'spanish');
    }

    public function index()
    {
        if (!has_permission('reviews', '', 'view')) {
            access_denied('reviews');
        }

        $filter = $this->input->get('filter');
        $approved = null;

        if ($filter === 'pending') {
            $approved = 0;
        } elseif ($filter === 'approved') {
            $approved = 1;
        } elseif ($filter === 'all') {
            $approved = null;
        } else {
            $filter = 'pending';
            $approved = 0;
        }

        $data['filter']  = $filter;
        $data['reviews'] = $this->reviews_model->list_admin($approved);
        $data['title']   = _l('reviews_title');

        $this->load->view('manage', $data);
    }

    public function toggle_approve($id)
    {
        if (!has_permission('reviews', '', 'approve')) {
            echo json_encode(['success' => false, 'message' => _l('reviews_not_allowed')]);
            die;
        }

        $review = $this->reviews_model->get($id);
        if (!$review) {
            echo json_encode(['success' => false, 'message' => _l('reviews_not_found')]);
            die;
        }

        $new = $review->approved ? 0 : 1;

        $this->reviews_model->update($id, [
            'approved'    => $new,
            'approved_by' => $new ? get_staff_user_id() : null,
            'approved_at' => $new ? date('Y-m-d H:i:s') : null,
        ]);

        echo json_encode(['success' => true, 'approved' => $new]);
        die;
    }

    public function delete($id)
    {
        if (!has_permission('reviews', '', 'approve')) {
            access_denied('reviews');
        }

        $this->reviews_model->delete($id);
        set_alert('success', 'Eliminado');
        redirect(admin_url('reviews?filter=all'));
    }
}
