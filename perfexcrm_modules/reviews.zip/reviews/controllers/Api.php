<?php defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('reviews_model');
        $this->lang->load('reviews', 'spanish');
    }

    private function json($payload, $code = 200)
    {
        $this->output
            ->set_status_header($code)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($payload));
    }

    public function submit()
    {
        $user_id     = $this->input->post('user_id', true);
        $user_name   = $this->input->post('user_name', true);
        $user_email  = $this->input->post('user_email', true);
        $rating      = $this->input->post('rating', true);
        $review_text = $this->input->post('review_text', false);

        if (empty($user_id) || empty($user_name)) {
            return $this->json(['success' => false, 'message' => _l('reviews_invalid')], 422);
        }

        $rating = ($rating === null || $rating === '') ? null : (int)$rating;
        if ($rating !== null && ($rating < 1 || $rating > 5)) {
            $rating = null;
        }

        $data = [
            'user_id'     => $user_id,
            'user_name'   => $user_name,
            'user_email'  => $user_email,
            'rating'      => $rating,
            'review_text' => $review_text,
            'media_path'  => null,
            'media_type'  => null,
            'approved'    => 0,
        ];

        if (!empty($_FILES['media']['name'])) {
            if (!is_dir(REVIEWS_UPLOAD_PATH)) {
                @mkdir(REVIEWS_UPLOAD_PATH, 0755, true);
            }

            $config['upload_path']   = REVIEWS_UPLOAD_PATH;
            $config['allowed_types'] = 'jpg|jpeg|png|webp|gif|mp4|mov|m4v|webm';
            $config['max_size']      = 102400; // 100MB
            $config['encrypt_name']  = true;

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('media')) {
                return $this->json([
                    'success' => false,
                    'message' => _l('reviews_upload_failed'),
                    'error'   => $this->upload->display_errors('', '')
                ], 400);
            }

            $up = $this->upload->data();
            $ext = strtolower(ltrim($up['file_ext'], '.'));
            $is_video = in_array($ext, ['mp4','mov','m4v','webm']);
            $is_image = in_array($ext, ['jpg','jpeg','png','webp','gif']);

            $data['media_type'] = $is_video ? 'video' : ($is_image ? 'image' : null);
            $data['media_path'] = 'uploads/reviews/' . $up['file_name'];
        }

        $id = $this->reviews_model->add($data);

        return $this->json(['success' => true, 'id' => $id]);
    }

    public function list_public()
    {
        $limit  = (int)$this->input->get('limit') ?: 50;
        $offset = (int)$this->input->get('offset') ?: 0;

        $rows = $this->reviews_model->list_public_approved($limit, $offset);

        return $this->json(['success' => true, 'data' => $rows]);
    }
}
