<?php defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Menu Reviews
Description: Módulo para recibir reseñas (texto/foto/video) desde app y permitir aprobación por staff.
Version: 1.1.0
Requires at least: 3.3.*
*/

define('REVIEWS_MODULE_NAME', 'reviews');
define('REVIEWS_UPLOAD_PATH', FCPATH . 'uploads/reviews/');

hooks()->add_action('admin_init', 'reviews_module_init_menu_items');
hooks()->add_action('admin_init', 'reviews_module_register_permissions');

register_activation_hook(REVIEWS_MODULE_NAME, 'reviews_module_activation_hook');

function reviews_module_activation_hook()
{
    require_once(__DIR__ . '/install.php');
}

function reviews_module_init_menu_items()
{
    $CI = &get_instance();

    if (has_permission('reviews', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('reviews', [
            'name'     => 'Menu Reviews',
            'href'     => admin_url('reviews'),
            'position' => 35,
            'icon'     => 'fa fa-star',
        ]);
    }
}

function reviews_module_register_permissions()
{
    register_staff_capabilities('reviews', [
        'view'    => _l('permission_view'),
        'approve' => _l('reviews_permission_approve'),
    ], 'Menu Reviews');
}
