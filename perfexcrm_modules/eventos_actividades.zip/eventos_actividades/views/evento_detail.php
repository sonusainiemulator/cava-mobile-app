<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel_s">
                    <div class="panel-body">
                        <h4 class="no-margin">
                            <?php echo $title; ?>
                        </h4>
                        <hr class="hr-panel-heading" />
                        <?php echo form_open(admin_url('eventos_actividades/evento'), array('id' => 'evento_form')); ?>
                            <input type="hidden" name="id" value="<?php echo isset($evento) ? $evento->id : ''; ?>">

                            <div class="form-group tw-mb-4">
                                <label class="control-label">Event Name</label>
                                <input type="text" name="nombre" class="form-control" value="<?php echo isset($evento) ? $evento->nombre : ''; ?>" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Date</label>
                                        <input type="date" name="fecha" class="form-control" value="<?php echo isset($evento) ? $evento->fecha : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Time</label>
                                        <input type="time" name="hora" class="form-control" value="<?php echo isset($evento) ? $evento->hora : ''; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Country</label>
                                        <input type="text" name="pais" class="form-control" value="<?php echo isset($evento) ? $evento->pais : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">City/State</label>
                                        <input type="text" name="ciudad" class="form-control" value="<?php echo isset($evento) ? $evento->ciudad : ''; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Address</label>
                                <input type="text" name="direccion" class="form-control" value="<?php echo isset($evento) ? $evento->direccion : ''; ?>">
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Latitude</label>
                                        <input type="text" name="lat" class="form-control" value="<?php echo isset($evento) ? $evento->lat : ''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Longitude</label>
                                        <input type="text" name="lng" class="form-control" value="<?php echo isset($evento) ? $evento->lng : ''; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="text-right">
                                <a href="<?php echo admin_url('eventos_actividades'); ?>" class="btn btn-default">Cancel</a>
                                <button type="submit" class="btn btn-info"><?php echo isset($evento) ? 'Update Event' : 'Publish Event'; ?></button>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php init_tail(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        appValidateForm($('#evento_form'), {
            nombre: 'required'
        });
    });
</script>
