<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
  .muro-hero{
    border-radius: 16px;
    background: linear-gradient(135deg, rgba(0,0,0,0.06), rgba(0,0,0,0.02));
    border: 1px solid rgba(0,0,0,0.08);
    padding: 18px 18px 16px 18px;
    margin-top: 10px;
  }
  .muro-hero-title{
    font-size: 28px;
    font-weight: 900;
    margin: 0;
    letter-spacing: .2px;
  }
  .muro-hero-sub{
    margin-top: 6px;
    color: #666;
    font-size: 13px;
  }
  .muro-actions{
    margin-top: 12px;
    display:flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items:center;
  }
  .muro-img-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:14px}
  .muro-img-card{border:1px dashed #d9d9d9;border-radius:14px;padding:12px;background:#fafafa;min-height:170px}
  .muro-img-preview{width:100%;height:110px;object-fit:contain;border-radius:12px;background:#fff;border:1px solid #eee}
  .slot-label{font-size:12px;color:#666;margin-top:10px;margin-bottom:6px}
  .marca-info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px}
  .info-item{background:#fff;border:1px solid #eee;border-radius:14px;padding:12px}
  .info-item .k{font-size:12px;color:#777;margin-bottom:6px}
  .info-item .v{font-size:14px;font-weight:700;color:#222;word-break:break-word}
</style>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">

            <h4 class="no-margin">Marcas / Muro</h4>
            <hr>

            <?php echo form_open(admin_url('marcas/muro'), ['method' => 'get']); ?>
              <div class="row">
                <div class="col-md-8">
                  <div class="form-group">
                    <label>Buscar marca</label>
                    <input type="text" class="form-control" name="q" value="<?php echo html_escape($q ?? ''); ?>" placeholder="Escribe el nombre...">
                  </div>
                </div>
                <div class="col-md-4" style="padding-top:26px;">
                  <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
              </div>
            <?php echo form_close(); ?>

            <?php if (!empty($results)): ?>
              <div class="panel_s" style="border:1px solid #eee;border-radius:14px;">
                <div class="panel-body" style="padding:10px 12px;">
                  <strong>Selecciona una marca</strong>
                  <div style="margin-top:10px;">
                    <?php foreach ($results as $r): ?>
                      <?php
                        $nameField = $display_name ?? 'id';
                        $label = isset($r[$nameField]) ? $r[$nameField] : ('ID ' . $r['id']);
                      ?>
                      <a href="<?php echo admin_url('marcas/muro/' . (int)$r['id']); ?>"
                         class="label label-default"
                         style="display:inline-block;margin:4px 6px 4px 0;padding:9px 12px;border-radius:14px;">
                        <?php echo html_escape($label); ?>
                      </a>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php endif; ?>

            <?php if (!empty($selected) && isset($selected['id'])): ?>
              <?php
                $nameField = $display_name ?? 'id';
                $title = isset($selected[$nameField]) ? $selected[$nameField] : ('Marca #' . (int)$selected['id']);
              ?>
              <!-- ENCABEZADO (HERO) -->
              <div class="muro-hero">
                <div class="muro-hero-title"><?php echo html_escape($title); ?></div>
                <div class="muro-hero-sub">ID: <?php echo (int)$selected['id']; ?> • Sube hasta 4 imágenes PNG y se verán en el encabezado.</div>

                <div class="muro-actions">
                  <a class="btn btn-default" href="<?php echo admin_url('marcas/edit/' . (int)$selected['id']); ?>">
                    <i class="fa fa-pencil"></i> Editar marca
                  </a>
                  <a class="btn btn-default" href="<?php echo admin_url('marcas'); ?>">
                    <i class="fa fa-list"></i> Volver a listado
                  </a>
                </div>

                <?php echo form_open_multipart(admin_url('marcas/muro_upload/' . (int)$selected['id'])); ?>
                  <div class="muro-img-grid">
                    <?php for ($i=1; $i<=4; $i++): ?>
                      <div class="muro-img-card">
                        <?php if (!empty($muro_images[$i])): ?>
                          <img class="muro-img-preview" src="<?php echo $muro_images[$i]; ?>" alt="muro img <?php echo $i; ?>">
                        <?php else: ?>
                          <div class="muro-img-preview" style="display:flex;align-items:center;justify-content:center;color:#999;">
                            Sin imagen
                          </div>
                        <?php endif; ?>
                        <div class="slot-label">Imagen <?php echo $i; ?> (PNG)</div>
                        <input type="file" class="form-control" name="muro_img<?php echo $i; ?>" accept="image/png">
                      </div>
                    <?php endfor; ?>
                  </div>

                  <div style="margin-top:12px;">
                    <button class="btn btn-primary" type="submit">
                      <i class="fa fa-save"></i> Guardar imágenes
                    </button>
                  </div>
                <?php echo form_close(); ?>
              </div>

              <!-- INFO -->
              <div class="marca-info-grid">
                <?php foreach (($fields ?? []) as $f): ?>
                  <?php if (!array_key_exists($f, $selected)) { continue; } ?>
                  <div class="info-item">
                    <div class="k"><?php echo html_escape(ucfirst(str_replace('_',' ', $f))); ?></div>
                    <div class="v">
                      <?php
                        $isImg = (!empty($image_fields) && in_array($f, $image_fields));
                        if ($isImg && !empty($selected[$f])) {
                          echo '<img src="' . base_url('uploads/marcas/' . $selected[$f]) . '" style="width:90px;height:auto;border-radius:12px;border:1px solid #eee;background:#fff;">';
                        } else {
                          echo html_escape((string)$selected[$f]);
                        }
                      ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php init_tail(); ?>
</body>
</html>
