<?php
defined('BASEPATH') or exit('No direct script access allowed');
/*
Module Name: Marcas
Description: Gestión de marcas usando tblmarcas + Muro (sin cambios en BD).
Version: 1.1.0
Author: EREISE
*/

hooks()->add_action('admin_init', 'marcas_register_permissions');
hooks()->add_action('admin_init', 'marcas_init_menu_items');

function marcas_register_permissions()
{
    // Register capabilities if Perfex helper exists.
    if (function_exists('register_staff_capabilities')) {
        $capabilities = [
            'view'   => _l('permission_view'),
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
        ];
        register_staff_capabilities('marcas', $capabilities, _l('Marcas'));
    }
}

function marcas_init_menu_items()
{
    $CI = &get_instance();

    // Show for admins always; for staff, require permission view
    $can_view = (function_exists('is_admin') && is_admin()) || has_permission('marcas', '', 'view');

    if ($can_view) {
        // Main menu: Marcas
        $CI->app_menu->add_sidebar_menu_item('marcas', [
            'name'     => 'Marcas',
            'href'     => admin_url('marcas'),
            'icon'     => 'fa fa-star',
            'position' => 50,
        ]);

        // Independent menu: Muro (so it ALWAYS appears)
        $CI->app_menu->add_sidebar_menu_item('marcas_muro', [
            'name'     => 'Muro',
            'href'     => admin_url('marcas/muro'),
            'icon'     => 'fa fa-th-large',
            'position' => 51,
        ]);
    }
}
