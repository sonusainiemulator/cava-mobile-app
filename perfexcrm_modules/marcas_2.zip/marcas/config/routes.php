<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Explicit routes to avoid 404 in some Perfex setups.
 * These routes are for the ADMIN area.
 */
$route['admin/marcas'] = 'marcas/marcas/index';
$route['admin/marcas/index'] = 'marcas/marcas/index';
$route['admin/marcas/edit/(:num)'] = 'marcas/marcas/edit/$1';
$route['admin/marcas/create'] = 'marcas/marcas/create';
$route['admin/marcas/update/(:num)'] = 'marcas/marcas/update/$1';
$route['admin/marcas/delete/(:num)'] = 'marcas/marcas/delete/$1';

$route['admin/marcas/muro'] = 'marcas/marcas/muro';
$route['admin/marcas/muro/(:num)'] = 'marcas/marcas/muro/$1';
$route['admin/marcas/muro_upload/(:num)'] = 'marcas/marcas/muro_upload/$1';
