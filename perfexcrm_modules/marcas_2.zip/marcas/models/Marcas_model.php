<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Marcas_model extends App_Model
{
    protected $table;

    public function __construct()
    {
        parent::__construct();
        $this->table = 'tblmarcas';
    }

    public function get($id = '')
    {
        if ($id !== '' && $id !== null) {
            $this->db->where('id', $id);
            return $this->db->get($this->table)->row_array();
        }
        return $this->db->get($this->table)->result_array();
    }

    public function get_fields()
    {
        return $this->db->list_fields($this->table);
    }

    public function get_display_name_field()
    {
        $fields = $this->get_fields();
        foreach ($fields as $f) {
            if (strtolower($f) === 'nombre' || strtolower($f) === 'name') return $f;
        }
        foreach ($fields as $f) {
            if (strtolower($f) !== 'id') return $f;
        }
        return 'id';
    }

    public function get_image_fields()
    {
        $fields = $this->get_fields();
        $image_fields = [];
        foreach ($fields as $field) {
            $lower = strtolower($field);
            if (strpos($lower,'imagen') !== false || strpos($lower,'image') !== false || strpos($lower,'logo') !== false || strpos($lower,'foto') !== false) {
                $image_fields[] = $field;
            }
        }
        return $image_fields;
    }

    public function search($q, $limit = 25)
    {
        $q = trim((string)$q);
        if ($q === '') {
            $this->db->limit($limit);
            return $this->db->get($this->table)->result_array();
        }
        $name_field = $this->get_display_name_field();
        $this->db->like($name_field, $q);
        $this->db->limit($limit);
        return $this->db->get($this->table)->result_array();
    }

    public function add($data)
    {
        $fields = $this->get_fields();
        $insert = [];
        foreach ($fields as $field) {
            if ($field === 'id') continue;
            if (isset($data[$field])) $insert[$field] = $data[$field];
        }
        if (empty($insert)) return false;
        $this->db->insert($this->table, $insert);
        return $this->db->insert_id();
    }

    public function update($data, $id)
    {
        $fields = $this->get_fields();
        $update = [];
        foreach ($fields as $field) {
            if ($field === 'id') continue;
            if (isset($data[$field])) $update[$field] = $data[$field];
        }
        if (empty($update)) return false;
        $this->db->where('id', $id);
        $this->db->update($this->table, $update);
        return $this->db->affected_rows() > 0;
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete($this->table);
        return $this->db->affected_rows() > 0;
    }

    // MURO IMAGES (sin BD): /uploads/marcas/muro/{id}/img{n}.png
    public function get_muro_dir($id)
    {
        return FCPATH . 'uploads/marcas/muro/' . (int)$id . '/';
    }

    public function get_muro_image_url($id, $slot)
    {
        $slot = (int)$slot;
        $file = $this->get_muro_dir($id) . 'img' . $slot . '.png';
        if (is_file($file)) {
            return base_url('uploads/marcas/muro/' . (int)$id . '/img' . $slot . '.png') . '?v=' . filemtime($file);
        }
        return null;
    }

    public function save_muro_image($id, $slot, $field, &$error = null)
    {
        $error = null;
        if (!isset($_FILES[$field]) || empty($_FILES[$field]['name'])) return true;

        $name = $_FILES[$field]['name'];
        $tmp  = $_FILES[$field]['tmp_name'];
        $size = (int)$_FILES[$field]['size'];

        if ($size <= 0) { $error = 'Archivo inválido para imagen ' . (int)$slot; return false; }

        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext !== 'png') { $error = 'Solo se permiten PNG (imagen ' . (int)$slot . ')'; return false; }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = $finfo ? finfo_file($finfo, $tmp) : '';
            if ($finfo) finfo_close($finfo);
            if ($mime !== 'image/png') { $error = 'El archivo no parece ser PNG (imagen ' . (int)$slot . ')'; return false; }
        }

        if ($size > 3 * 1024 * 1024) { $error = 'PNG demasiado grande (máx 3MB) (imagen ' . (int)$slot . ')'; return false; }

        $dir = $this->get_muro_dir($id);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);

        $dest = $dir . 'img' . (int)$slot . '.png';
        if (!@move_uploaded_file($tmp, $dest)) { $error = 'No se pudo guardar la imagen ' . (int)$slot; return false; }

        return true;
    }
}
