<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Marcas extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('marcas/marcas_model');
    }

    private function can_view()
    {
        return (function_exists('is_admin') && is_admin()) || has_permission('marcas', '', 'view');
    }

    private function can_edit()
    {
        return (function_exists('is_admin') && is_admin()) || has_permission('marcas', '', 'edit');
    }

    private function can_create()
    {
        return (function_exists('is_admin') && is_admin()) || has_permission('marcas', '', 'create');
    }

    private function can_delete()
    {
        return (function_exists('is_admin') && is_admin()) || has_permission('marcas', '', 'delete');
    }

    public function index()
    {
        if (!$this->can_view()) access_denied('marcas');

        $data['title']        = 'Marcas';
        $data['marcas']       = $this->marcas_model->get();
        $data['fields']       = $this->marcas_model->get_fields();
        $data['image_fields'] = $this->marcas_model->get_image_fields();
        $data['edit_mode']    = false;
        $data['marca']        = [];
        $data['can_edit']     = $this->can_edit();

        $this->load->view('manage', $data);
    }

    public function edit($id)
    {
        if (!$this->can_edit()) access_denied('marcas');

        $marca = $this->marcas_model->get($id);
        if (!$marca) {
            set_alert('danger', 'Marca no encontrada');
            redirect(admin_url('marcas'));
        }

        $data['title']        = 'Editar marca';
        $data['marcas']       = $this->marcas_model->get();
        $data['fields']       = $this->marcas_model->get_fields();
        $data['image_fields'] = $this->marcas_model->get_image_fields();
        $data['edit_mode']    = true;
        $data['marca']        = $marca;
        $data['can_edit']     = true;

        $this->load->view('manage', $data);
    }

    // MURO: /admin/marcas/muro o /admin/marcas/muro/{id} (y soporta ?id=)
    public function muro($id = null)
    {
        if (!$this->can_view()) access_denied('marcas');

        $seg_id = (int)$id;
        $get_id = (int)$this->input->get('id');
        $selected_id = $seg_id > 0 ? $seg_id : $get_id;

        $q = trim((string)$this->input->get('q'));

        $data['title']        = 'Muro';
        $data['q']            = $q;
        $data['results']      = $this->marcas_model->search($q, 25);
        $data['fields']       = $this->marcas_model->get_fields();
        $data['image_fields'] = $this->marcas_model->get_image_fields();
        $data['display_name'] = $this->marcas_model->get_display_name_field();
        $data['can_edit']     = $this->can_edit();

        // Si buscó y no seleccionó, auto selecciona el primero
        if ($selected_id <= 0 && $q !== '' && !empty($data['results']) && isset($data['results'][0]['id'])) {
            $selected_id = (int)$data['results'][0]['id'];
        }

        $data['selected_id'] = $selected_id;
        $data['selected']    = $selected_id ? $this->marcas_model->get($selected_id) : null;

        $data['muro_images'] = [];
        if ($selected_id) {
            for ($i = 1; $i <= 4; $i++) {
                $data['muro_images'][$i] = $this->marcas_model->get_muro_image_url($selected_id, $i);
            }
        }

        $this->load->view('muro', $data);
    }

    public function muro_upload($id)
    {
        if (!$this->can_edit()) access_denied('marcas');

        $id = (int)$id;
        if ($id <= 0) show_404();

        $errors = [];
        for ($i = 1; $i <= 4; $i++) {
            $field = 'muro_img' . $i;
            if (isset($_FILES[$field]) && !empty($_FILES[$field]['name'])) {
                $ok = $this->marcas_model->save_muro_image($id, $i, $field, $err);
                if (!$ok) $errors[] = $err ?: ('Error subiendo imagen ' . $i);
            }
        }

        if (!empty($errors)) set_alert('danger', implode('<br>', $errors));
        else set_alert('success', 'Imágenes del muro actualizadas');

        redirect(admin_url('marcas/muro/' . $id));
    }

    protected function handle_image_uploads($image_fields)
    {
        $uploaded = [];
        if (empty($image_fields)) return $uploaded;

        $path = FCPATH . 'uploads/marcas/';
        if (!is_dir($path)) @mkdir($path, 0755, true);

        $this->load->library('upload');

        foreach ($image_fields as $field) {
            if (isset($_FILES[$field]) && !empty($_FILES[$field]['name'])) {
                $config = [];
                $config['upload_path']   = $path;
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['max_size']      = 2048;
                $config['file_name']     = $field . '_' . time() . '_' . uniqid();

                $this->upload->initialize($config);

                if ($this->upload->do_upload($field)) {
                    $data = $this->upload->data();
                    $uploaded[$field] = $data['file_name'];
                }
            }
        }
        return $uploaded;
    }

    public function create()
    {
        if (!$this->can_create()) access_denied('marcas');

        $post = $this->input->post(null, false);
        if ($post) {
            $image_fields = $this->marcas_model->get_image_fields();
            $uploaded     = $this->handle_image_uploads($image_fields);
            foreach ($uploaded as $field => $filename) $post[$field] = $filename;

            $id = $this->marcas_model->add($post);
            if ($id) set_alert('success', _l('added_successfully', 'Marcas'));
            else set_alert('danger', _l('problem_adding', 'Marcas'));
        }
        redirect(admin_url('marcas'));
    }

    public function update($id)
    {
        if (!$this->can_edit()) access_denied('marcas');

        $post = $this->input->post(null, false);
        if ($post) {
            $image_fields = $this->marcas_model->get_image_fields();
            $uploaded     = $this->handle_image_uploads($image_fields);
            foreach ($uploaded as $field => $filename) $post[$field] = $filename;

            $success = $this->marcas_model->update($post, $id);
            if ($success) set_alert('success', _l('updated_successfully', 'Marcas'));
            else set_alert('danger', _l('problem_updating', 'Marcas'));
        }
        redirect(admin_url('marcas'));
    }

    public function delete($id)
    {
        if (!$this->can_delete()) access_denied('marcas');

        $success = $this->marcas_model->delete($id);
        if ($success) set_alert('success', _l('deleted', 'Marcas'));
        else set_alert('danger', _l('problem_deleting', 'Marcas'));
        redirect(admin_url('marcas'));
    }
}
