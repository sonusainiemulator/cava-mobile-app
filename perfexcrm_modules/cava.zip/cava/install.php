<?php

defined('BASEPATH') or exit('No direct script access allowed');

$CI = &get_instance();

if (!$CI->db->table_exists(db_prefix() . 'cava_wines')) {
    $CI->db->query('CREATE TABLE `' . db_prefix() . "cava_wines` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(191) NOT NULL,
        `image` VARCHAR(191) NOT NULL,
        `created_by` INT(11) DEFAULT NULL,
        `date_created` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
}

if (!$CI->db->table_exists(db_prefix() . 'cava_user_wines')) {
    $CI->db->query('CREATE TABLE `' . db_prefix() . "cava_user_wines` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `user_id` INT(11) NOT NULL,
        `wine_id` INT(11) NOT NULL,
        `date_added` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `user_wine_unique` (`user_id`, `wine_id`),
        KEY `user_id` (`user_id`),
        KEY `wine_id` (`wine_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
}
